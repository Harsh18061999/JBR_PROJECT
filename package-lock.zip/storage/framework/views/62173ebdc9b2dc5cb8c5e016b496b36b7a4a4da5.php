<?php $__env->startSection('title', 'Blank layout - Layouts'); ?>

<?php $__env->startSection('content'); ?>
<h4 class="fw-bold p-4">Blank Page</h4>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/blankLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sneat-html-admin-template\html-laravel-free\full-version\resources\views/content/layouts-example/layouts-blank.blade.php ENDPATH**/ ?>