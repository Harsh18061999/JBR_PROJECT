


<?php $__env->startSection('title', ' Horizontal Layouts - Forms'); ?>

<?php $__env->startSection('content'); ?>

<div class="card shadow bg-transparent" id="grad1">
    <div class="row mt-0">
        <div class="text-center p-0">
            <div class="card px-0 pt-4 pb-0 d-flex justify-content-center">
                <img src="<?php echo e(asset('/assets/img/JBR_Staffing_Solutions.jpg')); ?>" class="m-auto" alt="" width="250px" height="250px">
                <h2 class="mb-4">Thanks For Register</h2>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('uselayouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\New folder\resources\views/content/user/employee/success.blade.php ENDPATH**/ ?>