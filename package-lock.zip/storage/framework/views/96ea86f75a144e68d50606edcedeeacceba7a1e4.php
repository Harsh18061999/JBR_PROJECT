

<?php $__env->startSection('title', ' Horizontal Layouts - Forms'); ?>
<style>
table.dataTable thead .sorting, 
table.dataTable thead .sorting_asc, 
table.dataTable thead .sorting_desc {
    background : none !important;
}
</style>
<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center">

    <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"><i class="fa-sharp fa-solid fa-users mx-2"></i> Employee</h4>
    <div class="mb-4">
        <a href="<?php echo e(route('employee.create')); ?>" class="btn btn-primary"><i class="fa-sharp fa-solid fa-user-plus mx-2"></i>Add Employee</a>
    </div>
</div>
<div class="card shadow bg-white">
    <div class="card-body">
        <div class="table-responsive text-nowrap">
            <?php echo $dataTable->table(['class' => 'w-100'], true); ?>

        </div>
    </div>
</div>

<?php echo e($dataTable->scripts()); ?>

<script src="<?php echo e(asset("assets/js/custom/employee.js")); ?>"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\New folder\resources\views/content/employee/index.blade.php ENDPATH**/ ?>